# -*- coding: utf-8 -*-
# sudo python setup.py register sdist upload

from distutils.core import setup

PACKAGE = "fileserver"
NAME = "fileserver"
DESCRIPTION = "tornado simple HttpService."
AUTHOR = "syf"
AUTHOR_EMAIL = "git@suyafei.com"
URL = "https://github.com/myyyy"
VERSION = '0.25'

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    # long_description=read("README.md"),
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    license="Apache License, Version 2.0",
    url=URL,
    packages=["fileserver"],
    package_data={'fileserver': ['static/*',
         'templates/index.html'
     ]},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Web Environment",
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
    ],
    zip_safe=False,
)
